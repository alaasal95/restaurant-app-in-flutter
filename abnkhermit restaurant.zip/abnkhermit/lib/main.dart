import 'package:abnkhermit/p2.dart';
import 'package:abnkhermit/p3.dart';
import 'package:flutter/material.dart';
import 'package:abnkhermit/p1.dart';
import 'package:abnkhermit/p4.dart';
import 'package:abnkhermit/p5.dart';
import 'package:abnkhermit/p6.dart';
import 'package:abnkhermit/p7.dart';
void main(){
  runApp(
    new MaterialApp(
 home:new myApp(),
    ),
  );
}




class myApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {

    return new MaterialApp(

        title: 'MyApp',

        routes: <String,WidgetBuilder>{
          '/p1':(BuildContext context)=> new Abn(),
          '/p2':(BuildContext context)=> new p2(),
          '/p3':(BuildContext context)=> new p3(),
          '/p4':(BuildContext context)=> new p4(),
          '/p5':(BuildContext context)=> new p5(),
          '/p6':(BuildContext context)=> new p6(),
          '/p7':(BuildContext context)=> new p7(),


        },
        home: Abn()
    );
  }

}