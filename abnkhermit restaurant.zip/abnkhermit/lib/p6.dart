
import 'package:flutter/material.dart';

class p6 extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _p66();
  }
}

class _p66 extends State<p6> {


  final TextEditingController _orderController=new TextEditingController();
  final TextEditingController _orderController2=new TextEditingController();
  final TextEditingController _orderController3=new TextEditingController();
  final TextEditingController _orderController4=new TextEditingController();
  String myOrder='';
  String myOrder2='';
  String  myOrder3='';
  String  myOrder4='';

  int myOrder_all;
  bool j1=false;
  bool j2=false;
  bool j3=false;
  bool j4=false;
  void _onCleer() {
    setState(() {
      _orderController.clear();
      _orderController2.clear();
      _orderController3..clear();
      _orderController4.clear();
      j1=false;j2=false;j3=false;j4=false;
      myOrder='0';
      myOrder2='0';
      myOrder3='0';
      myOrder4='0';
      myOrder_all=0;
    });

  }

  String orderPrice(String orderPrice,deleverPrice) {
    if (orderPrice.isNotEmpty && int.parse(orderPrice) > 0) {
      int result= int.parse(orderPrice) * deleverPrice;
      return myOrder= '$result';

    } else {
      //print('Please enter avalid Price!');

      return myOrder='  رجاءا ادخل عدد صحيح ثم اضغط على الاختيار فوق!';


    }
  }


  String orderPrice2(String orderPrice2,deleverPrice) {
    if (orderPrice2.isNotEmpty && int.parse(orderPrice2) > 0) {
      int result= int.parse(orderPrice2) * deleverPrice;
      return myOrder2= '$result';

    } else {
      //print('Please enter avalid Price!');

      return myOrder2='  رجاءا ادخل عدد صحيح ثم اضغط على الاختيار فوق!';


    }
  }

  String orderPrice3(String orderPrice3,deleverPrice) {
    if (orderPrice3.isNotEmpty && int.parse(orderPrice3) > 0) {
      int result= int.parse(orderPrice3) * deleverPrice;
      return myOrder3= '$result';

    } else {
      //print('Please enter avalid Price!');

      return myOrder3='  رجاءا ادخل عدد صحيح ثم اضغط على الاختيار فوق!';


    }
  }

  String orderPrice4(String orderPrice4,deleverPrice) {
    if (orderPrice4.isNotEmpty && int.parse(orderPrice4) > 0) {
      int result= int.parse(orderPrice4) * deleverPrice;
      return myOrder4= '$result';

    } else {
      //print('Please enter avalid Price!');

      return myOrder4='  رجاءا ادخل عدد صحيح ثم اضغط على الاختيار فوق!';


    }
  }


  radioEventHandler1(bool value1) {

    setState(() {

      j1 =value1;

      switch ( j1) {
        case true:
          orderPrice(_orderController.text, 10000);zoB();
          myOrder= ' $myOrder '; myOrder_all=myOrder_all;
          break;
        case false:

          myOrder= 'اضغط على زر الاختيار!';

          break;

      }


    });
  }



  radioEventHandler2(bool value1) {

    setState(() {

      j2 =value1;

      switch ( j2) {
        case true:
          orderPrice2(_orderController2.text, 9000); zoB();
          myOrder2 = ' $myOrder2 ';myOrder_all=myOrder_all;

          break;
        case false:

          myOrder2= 'اضغط على زر الاختيار!';

          break;

      }


    });
  }



  radioEventHandler3(bool value1) {

    setState(() {

      j3 =value1;

      switch ( j3) {
        case true:
          orderPrice3(_orderController3.text,12000); zoB();
          myOrder3 = ' $myOrder3 ';myOrder_all=myOrder_all;

          break;
        case false:

          myOrder3= 'اضغط على زر الاختيار!';

          break;

      }


    });
  }



  radioEventHandler4(bool value1) {

    setState(() {

      j4 =value1;

      switch ( j4) {
        case true:
          orderPrice4(_orderController4.text,12000); zoB();
          myOrder4 = ' $myOrder4 ';myOrder_all=myOrder_all;

          break;
        case false:

          myOrder4= 'اضغط على زر الاختيار!';

          break;

      }


    });
  }


  zoB()  {setState(() {

    ///1)T=>T=>T=>T
    if(
    (_orderController.text.isNotEmpty && int.parse(_orderController.text) > 0)
        && (_orderController2.text.isNotEmpty &&int.parse(_orderController2.text) > 0)
        && (_orderController3.text.isNotEmpty &&int.parse(_orderController3.text) > 0)
        && (_orderController4.text.isNotEmpty &&int.parse(_orderController4.text) > 0)
    )
    {
      myOrder_all=int.parse(myOrder) + int.parse(myOrder2) + int.parse(myOrder3)+ int.parse(myOrder4);

    }
    ///2)T=>T=>T=>F
    else if(

    (_orderController.text.isNotEmpty && int.parse(_orderController.text) > 0)
        && (_orderController2.text.isNotEmpty &&int.parse(_orderController2.text) > 0)
        && (_orderController3.text.isNotEmpty &&int.parse(_orderController3.text) > 0)
        && (_orderController4.text.isEmpty)

    )
    {

      myOrder_all=int.parse(myOrder) + int.parse(myOrder2) + int.parse(myOrder3)+0;

    }
    ///3)T=>T=>F=>T
    else if(
    (_orderController.text.isNotEmpty && int.parse(_orderController.text) > 0)
        && (_orderController2.text.isNotEmpty && int.parse(_orderController2.text) > 0)
        && (_orderController3.text.isEmpty )
        && (_orderController4.text.isNotEmpty && int.parse(_orderController4.text) > 0)
    )
    {

      myOrder_all=int.parse(myOrder) + int.parse(myOrder2) +0+ int.parse(myOrder4);

    }
    ///4)T=>T=>F=>F

    else if(
    (_orderController.text.isNotEmpty && int.parse(_orderController.text) > 0)
        && (_orderController2.text.isNotEmpty && int.parse(_orderController2.text) > 0)
        && (_orderController3.text.isEmpty )
        && (_orderController4.text.isEmpty )
    )
    {

      myOrder_all=int.parse(myOrder) + int.parse(myOrder2) +0+0;

    }

    ///5)T=>F=>T=>T
    else if(
    (_orderController.text.isNotEmpty && int.parse(_orderController.text) > 0)
        &&  (_orderController2.text.isEmpty )
        &&  (_orderController3.text.isNotEmpty && int.parse(_orderController3.text) > 0)
        &&  (_orderController4.text.isNotEmpty && int.parse(_orderController4.text) > 0)
    )
    {

      myOrder_all=int.parse(myOrder) +0 + int.parse(myOrder3)+ int.parse(myOrder4);

    }

    ///6)T=>F=>T=>F
    else if(
    (_orderController.text.isNotEmpty && int.parse(_orderController.text) > 0)
        && (_orderController2.text.isEmpty )
        && (_orderController3.text.isNotEmpty &&int.parse(_orderController3.text) > 0)
        && (_orderController4.text.isEmpty )
    )
    {
      myOrder_all=int.parse(myOrder) +0+ int.parse(myOrder3)+ 0;

    }
    ///7)T=>F=>F=>T
    else if(

    (_orderController.text.isNotEmpty && int.parse(_orderController.text) > 0)
        && (_orderController2.text.isEmpty)
        && (_orderController3.text.isEmpty)
        && (_orderController4.text.isNotEmpty && int.parse(_orderController4.text) > 0)

    )
    {

      myOrder_all=int.parse(myOrder) + 0+0 + int.parse(myOrder4);

    }
    ///8)T=>F=>F=>F
    else if(
    (_orderController.text.isNotEmpty && int.parse(_orderController.text) > 0)
        && (_orderController2.text.isEmpty )
        && (_orderController3.text.isEmpty )
        && (_orderController4.text.isEmpty)
    )
    {
      myOrder_all=int.parse(myOrder) +0 + 0+ 0;

    }

    ///9)F=>T=>T=>T
    else if(
    (_orderController.text.isEmpty )
        && (_orderController2.text.isNotEmpty &&int.parse(_orderController2.text) > 0)
        && (_orderController3.text.isNotEmpty &&int.parse(_orderController3.text) > 0)
        && (_orderController4.text.isNotEmpty &&int.parse(_orderController4.text) > 0)
    )
    {
      myOrder_all=0 + int.parse(myOrder2) + int.parse(myOrder3)+ int.parse(myOrder4);

    }

    ///10)F=>T=>T=>F
    else if(
    (_orderController.text.isEmpty )
        && (_orderController2.text.isNotEmpty &&int.parse(_orderController2.text) > 0)
        && (_orderController3.text.isNotEmpty &&int.parse(_orderController3.text) > 0)
        && (_orderController4.text.isEmpty )
    )
    {
      myOrder_all=0 + int.parse(myOrder2) + int.parse(myOrder3)+0;

    }
    ///11)F=>T=>F=>T
    else if(
    (_orderController.text.isEmpty )
        && (_orderController2.text.isNotEmpty &&int.parse(_orderController2.text) > 0)
        && (_orderController3.text.isEmpty)
        && (_orderController4.text.isNotEmpty &&int.parse(_orderController4.text) > 0)
    )
    {
      myOrder_all=0 + int.parse(myOrder2) + 0+ int.parse(myOrder4);

    }

    ///12)F=>T=>F=>F
    else if(
    (_orderController.text.isEmpty )
        && (_orderController2.text.isNotEmpty &&int.parse(_orderController2.text) > 0)
        && (_orderController3.text.isEmpty )
        && (_orderController4.text.isEmpty)
    )
    {
      myOrder_all=0+ int.parse(myOrder2) +0+0;

    }
    ///13)F=>F=>T=>T
    else if(
    (_orderController.text.isEmpty )
        && (_orderController2.text.isEmpty )
        && (_orderController3.text.isNotEmpty &&int.parse(_orderController3.text) > 0)
        && (_orderController4.text.isNotEmpty &&int.parse(_orderController4.text) > 0)
    )
    {
      myOrder_all=0 + 0+ int.parse(myOrder3)+ int.parse(myOrder4);

    }
    ///14)F=>F=>T=>F
    else if(
    (_orderController.text.isEmpty )
        && (_orderController2.text.isEmpty )
        && (_orderController3.text.isNotEmpty &&int.parse(_orderController3.text) > 0)
        && (_orderController4.text.isEmpty )
    )
    {
      myOrder_all=0 + 0 + int.parse(myOrder3)+ 0;

    }
    ///15)F=>F=>F=>T
    else if(
    (_orderController.text.isEmpty )
        && (_orderController2.text.isEmpty )
        && (_orderController3.text.isEmpty )
        && (_orderController4.text.isNotEmpty &&int.parse(_orderController4.text) > 0)
    )
    {
      myOrder_all=0 + 0 + 0+ int.parse(myOrder4);

    }
    ///16)F=>F=>F=>F
    else if(
    (_orderController.text.isEmpty )
        && (_orderController2.text.isEmpty )
        && (_orderController3.text.isEmpty )
        && (_orderController4.text.isEmpty )
    )
    {
      myOrder_all=0 + 0 + 0+ 0;

    }

  });




  }



  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        actions: <Widget>[
          IconButton(
              icon: new Icon(
                Icons.fastfood,
                color: Colors.red,
                size: 40.0,
              )
          ),
        ],
        title: Text(
          '      إبن خرميط      ',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 25.0,
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontStyle: FontStyle.italic),
        ),
        backgroundColor: Colors.yellowAccent,
      ),
      body: new Container(

        child: new ListView(


          children: <Widget>[
            new Container(
              child: new Column(
                children: <Widget>[
                  new FlatButton(
                    color: Colors.deepPurple,
                    onPressed: () {},
                    child: new Text(
                      'وجبات غربية',
                      style: TextStyle(fontSize: 20.0, color: Colors.white),
                    ),
                  ),


                  /// /////////////////////الرئيسي////////      ////  ////////
                  new Column(

                    children: <Widget>[

///////////////////////////////////////choose_1//////////////////////////
                      new TextField(
                        style: TextStyle(fontSize: 18.0,),
                        decoration: InputDecoration(hintText:'هنا ادخل كم وجبة ترغب بها؟',
                            labelText:'اضغط هنا اولا',
                            icon:new Icon(Icons.add_circle,color: Colors.deepPurple,)
                        ),
                        controller: _orderController,
                      ),







                      new CheckboxListTile(
                        value: j1,
                        onChanged:radioEventHandler1 ,
                        title: Text('التاكوالمكسيكي',textAlign: TextAlign.center,
                        ),
                        subtitle:Text('سعر الوجبة الواحدة10000 IQD',
                          textDirection: TextDirection.rtl,
                          textAlign:TextAlign.center,
                        ),
                        activeColor: Colors.red,

                      ),



                      new Container(
                        child: new Text('التاكوالمكسيكي'' =$myOrder ''IQD',textDirection: TextDirection.rtl,
                          style: TextStyle(fontSize: 18.0,color: Colors.deepPurple),),
                      ),

                      Text('========',textAlign: TextAlign.center,
                          style: TextStyle(fontSize:30.0 ,color: Colors.red)),



///////////////////////////////////////choose_2//////////////////////////


                      new TextField(
                        style: TextStyle(fontSize: 18.0),
                        decoration: InputDecoration(hintText:'هنا ادخل كم وجبة ترغب بها؟',
                            labelText:'اضغط هنا اولا',
                            icon:new Icon(Icons.add_circle,color: Colors.deepPurple,)
                        ),
                        controller: _orderController2,
                      ),

                      new CheckboxListTile(
                        value: j2,
                        onChanged:radioEventHandler2 ,
                        title: Text('الأومليت الأسباني',textAlign: TextAlign.center,
                        ),
                        subtitle:Text('سعر الوجبة الواحدة 9000 IQD',
                          textDirection: TextDirection.rtl,
                          textAlign:TextAlign.center,
                        ),
                        activeColor: Colors.redAccent,
                      ),

                      new Container(
                        child: new Text('الأومليت الأسباني'' =$myOrder2 ''IQD',textDirection: TextDirection.rtl,
                          style: TextStyle(fontSize: 18.0,color: Colors.deepPurple),),
                      ),



                      Text('========',textAlign: TextAlign.center,
                          style: TextStyle(fontSize:30.0 ,color: Colors.red)),


///////////////////////////////////////choose_3//////////////////////////

                      new TextField(
                        style: TextStyle(fontSize: 18.0),
                        decoration: InputDecoration(hintText:'هنا ادخل كم وجبة ترغب بها؟',
                            labelText:'اضغط هنا اولا',
                            icon:new Icon(Icons.add_circle,color: Colors.deepPurple,)
                        ),
                        controller: _orderController3,
                      ),

                      new CheckboxListTile(
                        value: j3,
                        onChanged:radioEventHandler3 ,
                        title: Text('الدولماس اليوناني',textAlign: TextAlign.center,
                        ),
                        subtitle:Text('سعر الوجبة الواحدة 12000 IQD',
                          textDirection: TextDirection.rtl,
                          textAlign:TextAlign.center,
                        ),
                        activeColor: Colors.redAccent,
                      ),

                      new Container(
                        child: new Text('الدولماس اليوناني'' =$myOrder3 ''IQD',textDirection: TextDirection.rtl,
                          style: TextStyle(fontSize: 18.0,color: Colors.deepPurple),),
                      ),



                      Text('========',textAlign: TextAlign.center,
                          style: TextStyle(fontSize:30.0 ,color: Colors.red)),


                      ///////////////////////////////////////choose_4//////////////////////////


                      new TextField(
                        style: TextStyle(fontSize: 18.0),
                        decoration: InputDecoration(hintText:'هنا ادخل كم وجبة ترغب بها؟',
                            labelText:'اضغط هنا اولا',
                            icon:new Icon(Icons.add_circle,color: Colors.deepPurple,)
                        ),
                        controller: _orderController4,
                      ),

                      new CheckboxListTile(
                        value: j4,
                        onChanged:radioEventHandler4 ,
                        title: Text('الشبتزلي الالماني',textAlign: TextAlign.center,
                        ),
                        subtitle:Text('سعر الوجبة الواحدة 12000 IQD',
                          textDirection: TextDirection.rtl,
                          textAlign:TextAlign.center,
                        ),
                        activeColor: Colors.redAccent,
                      ),

                      new Container(
                        child: new Text('الشبتزلي الالماني'' =$myOrder4 ''IQD',textDirection: TextDirection.rtl,
                          style: TextStyle(fontSize: 18.0,color: Colors.deepPurple),),
                      ),


                      Text('========',textAlign: TextAlign.center,
                          style: TextStyle(fontSize:30.0 ,color: Colors.red)),



                      new Container(
                        child: new Text('السعر الكلي''=$myOrder_all ''IQD',
                          textDirection: TextDirection.rtl,
                          style: TextStyle(fontSize: 18.0,color: Colors.deepPurple,),),
                      ),
                      Padding(padding: EdgeInsets.all( 20.0)),

                      new Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[

                          new FlatButton(
                            color: Colors.deepPurple,
                            textColor: Colors.white,
                            onPressed:null,
                            child: new Text('ارسال الطلب',textDirection: TextDirection.rtl,
                            style: TextStyle(color: Colors.white,fontSize: 20.0),),
                          ),


                        ],
                      ),
                      Padding(padding: EdgeInsets.all( 10.0)),
                      new Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[

                          new FlatButton(
                            color: Colors.yellowAccent,
                            textColor: Colors.white,
                            child: new Text('رجوع',textDirection: TextDirection.rtl,
                              style: TextStyle(color: Colors.black,fontSize: 20.0),),
                            onPressed:(){Navigator.of(context).pushNamed('/p2');},
                          ),
                          Padding(padding: EdgeInsets.only( left:12.0,right: 12.0 )),
                          new FlatButton(
                            color: Colors.yellowAccent,
                            textColor: Colors.white,
                            onPressed: _onCleer, child: new Text('امسح !',textDirection: TextDirection.rtl,
                            style: TextStyle(color: Colors.black,fontSize: 20.0),),
                          ),
                        ],
                      ),



                    ],

                  ),
                ],
              ),

            ),






















          ],











        ),
      ),


    );

  }
}
