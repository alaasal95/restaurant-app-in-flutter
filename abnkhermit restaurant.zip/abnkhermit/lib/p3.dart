
import 'package:flutter/material.dart';

class p3 extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _p33();
  }
}

class _p33 extends State<p3> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(actions: <Widget>[
        IconButton(
            icon: new Icon(
              Icons.fastfood,
              color: Colors.red,
              size: 40.0,))
      ] ,

        title: Text(
          '      إبن خرميط      ',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 25.0,
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontStyle: FontStyle.italic),
        ),
        backgroundColor: Colors.yellowAccent,
      ),
      body: new Container(
        padding: EdgeInsets.only(top:1.0 ),
        child: new ListView(

          children: <Widget>[
            new Image.asset('img/abn24.jpg'),
           Padding(padding: EdgeInsets.only(top:9.0 ),),
            new Column(

             children: <Widget>[
               new Center(
                 child: new Column(
                   children: <Widget>[
                     new Text('07724782509 : رقم المبايل1',textDirection: TextDirection.ltr,
                       style: TextStyle(fontSize: 20.0,color: Colors.deepOrange),),

                     new Text('07824782523 : رقم المبايل2',textDirection: TextDirection.ltr,
                       style: TextStyle(fontSize: 20.0,color: Colors.deepOrange),),

                     new Text('abn@gmail.com: ايميل',textDirection: TextDirection.ltr,
                       style: TextStyle(fontSize: 20.0,color: Colors.deepOrange),),


                   ],
                 ),
               ),

             ],


           ),

          ],




        ),
      ),
    );
  }
}
