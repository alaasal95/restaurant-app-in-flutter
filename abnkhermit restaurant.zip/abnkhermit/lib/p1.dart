
import 'package:flutter/material.dart';

class Abn extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _ala();
  }

}

class _ala extends State<Abn>{
  @override
  Widget build(BuildContext context) {
    return new Scaffold(backgroundColor: Colors.white,
      appBar: AppBar (
          actions: <Widget>[
            IconButton(
                icon: new Icon(
                  Icons.fastfood,
                  color: Colors.red,
                size: 40.0,),onPressed: null,)
          ] ,
        title: Text('           إبن خرميط           ',textAlign: TextAlign.center,

        style: TextStyle(fontSize: 25.0,

        color: Colors.black,
          fontWeight: FontWeight.bold,
        fontStyle: FontStyle.italic),),
        backgroundColor: Colors.yellowAccent,
      ),
      body: new Container(

        child: new ListView(
          children: <Widget>[

                   Padding(padding: EdgeInsets.all(1.0),)  ,
            new Image.asset('img/kr1.jpg',
              alignment: Alignment.center,
            width:200 ,height:200 ,filterQuality: FilterQuality.high,),
            Padding(padding: EdgeInsets.all(10.0),)  ,
          new Container(
            child: new Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                new Text('( مطعم إبن خرميط يرحب بكم )',
                textDirection: TextDirection.rtl,
                style: TextStyle(fontSize:25.0 ,
                  fontWeight:FontWeight.w700,
                  fontStyle:FontStyle.italic,
                  color: Colors.deepOrange,
                ),),


               ////////center_faultbutton/////////////
                Padding(padding: EdgeInsets.all(20.0)),
                new Center(
                  child: new Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[


                      new FlatButton(color: Colors.deepPurple,
                        textColor: Colors.white,
                        onPressed: (){Navigator.of(context).pushNamed('/p2');}
                        , child: new Text('لرؤية الاطباق والطلب',
                            style: TextStyle(fontSize: 20.0)),

                      ),
                      Padding(padding: EdgeInsets.all(20.0)),
                      new FlatButton(
                        color: Colors.deepOrange,
                        textColor: Colors.white,
                        onPressed: (){Navigator.of(context).pushNamed('/p3');},
                        child: new Text(' للتواصل مع الأدارة',
                        style: TextStyle(fontSize: 20.0),),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )

          ],
        ),

      ),
    );
  }

}