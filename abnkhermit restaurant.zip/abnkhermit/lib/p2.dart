import 'package:flutter/material.dart';

class p2 extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _p22();
  }
}

class _p22 extends State<p2> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        actions: <Widget>[
          IconButton(
              icon: new Icon(
            Icons.fastfood,
            color: Colors.red,
            size: 40.0,
          ))
        ],
        title: Text(
          '      إبن خرميط      ',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 25.0,
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontStyle: FontStyle.italic),
        ),
        backgroundColor: Colors.yellowAccent,
      ),
      body: new Container(
        padding: EdgeInsets.only(top: 60.0),
        child: new ListView(


          children: <Widget>[
            new Center(
              child: new Column(
                children: <Widget>[
                  new FlatButton(
                    color: Colors.deepPurple,
                    onPressed: () {},
                    child: new Text(
                      ' أنواع الوجبات',
                      style: TextStyle(fontSize: 20.0, color: Colors.white),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 30.0),
                  ),

                  new Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[


                      ///////////////1////////////////
                      new FlatButton(
                        color: Colors.deepOrange,
                        onPressed: (){Navigator.of(context).pushNamed('/p7');},
                        child: new Text(
                          'مقبلات',
                          style: TextStyle(fontSize: 20.0, color: Colors.white),
                        ),
                      ),



                    ],
                  ),

                  new Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                       ////////////2///////////
                      new FlatButton(
                        color: Colors.deepOrange,
                        onPressed: (){Navigator.of(context).pushNamed('/p6');},
                        child: new Text(
                          'غربية',
                          style: TextStyle(fontSize: 20.0, color: Colors.white),
                        ),
                      ),
                      Padding(padding: EdgeInsets.only(left: 5.0,right: 5.0)),
                      /////////////3/////////////
                      new FlatButton(
                        color: Colors.deepOrange,

                        child: new Text(
                          'شرقية',
                          style: TextStyle(fontSize: 20.0, color: Colors.white),
                        ),
                        onPressed: (){Navigator.of(context).pushNamed('/p5');},
                      ),
                      Padding(padding: EdgeInsets.only(left: 5.0,right: 5.0)),

                      ///////////////4////////////////
                      new FlatButton(
                        color: Colors.deepOrange,
                        onPressed: (){Navigator.of(context).pushNamed('/p4');},
                        child: new Text(
                          'عراقية',
                          style: TextStyle(fontSize: 20.0, color: Colors.white),
                        ),
                      ),


                    ],
                  ),
                  Padding(padding: EdgeInsets.only(top:10.0 )),
                  new Image.asset('img/tow1.png'),


                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
